const Key = {
    key: 'objectways'
}

export default Key